package com.example.qeyasat

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale
import kotlin.math.ceil

data class Material(var type: String, var measure: String, var count: String)

class MainActivity : Activity() {
    private val materials = mutableListOf<Material>()
    private lateinit var list: LinearLayout
    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("materials", Context.MODE_PRIVATE)
        load()
        home()
    }

    private fun base() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(28, 28, 28, 28)
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun btn(text: String) = Button(this).apply {
        this.text = text
        textSize = 17f
        isAllCaps = false
    }

    private fun backButton() = btn("⬅️ رجوع للواجهة الرئيسية").apply {
        setOnClickListener { home() }
    }

    private fun home() {
        val l = base()

        l.addView(TextView(this).apply {
            text = "📏 قياسات - ادارة المواد"
            textSize = 26f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 8)
        })

        l.addView(TextView(this).apply {
            text = "المطور: محمد الفاتح"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        })

        val order = btn("📦 الطلبية")
        val feather = btn("📏 حساب عدد الريش")
        val weight = btn("⚖️ حساب وزن الريش")

        l.addView(order)
        l.addView(feather)
        l.addView(weight)

        order.setOnClickListener { orderScreen() }
        feather.setOnClickListener { featherScreen() }
        weight.setOnClickListener { weightScreen() }

        setContentView(l)
    }

    private fun orderScreen() {
        val l = base()

        l.addView(TextView(this).apply {
            text = "📏 قياسات - ادارة المواد"
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 10)
        })

        l.addView(backButton())

        val add = btn("➕ إضافة صنف")
        val share = btn("📤 مشاركة المعلومات")
        val clear = btn("🗑 مسح الكل")

        l.addView(add)
        l.addView(share)
        l.addView(clear)

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        l.addView(list)

        add.setOnClickListener { itemDialog(-1) }
        share.setOnClickListener { shareOrder() }
        clear.setOnClickListener {
            if (materials.isEmpty()) return@setOnClickListener
            AlertDialog.Builder(this)
                .setTitle("مسح الطلبية")
                .setMessage("هل تريد مسح جميع الأصناف؟")
                .setPositiveButton("نعم") { _, _ ->
                    materials.clear()
                    save()
                    refresh()
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }

        refresh()
        setContentView(l)
    }

    private fun refresh() {
        list.removeAllViews()

        if (materials.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "لا توجد أصناف بعد\nاضغط «إضافة صنف» لإدخال البضاعة"
                textSize = 18f
                gravity = Gravity.CENTER
                setPadding(10, 40, 10, 40)
            })
            return
        }

        materials.forEachIndexed { i, m ->
            val row = TextView(this).apply {
                text = "${i + 1}- ${m.type} | القياس: ${m.measure.ifBlank { "—" }} | العدد: ${m.count.ifBlank { "—" }}"
                textSize = 18f
                setPadding(10, 18, 10, 18)
            }
            row.setOnClickListener { itemDialog(i) }
            list.addView(row)
        }
    }

    // المستخدم يكتب اسم أي بضاعة يريدها، بدون أصناف مفروضة.
    private fun itemDialog(index: Int) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 10, 30, 10)
        }

        val type = EditText(this).apply {
            hint = "نوع المنتج (مثال: الجبهات)"
            inputType = InputType.TYPE_CLASS_TEXT
        }

        val measure = EditText(this).apply {
            hint = "القياس (مثال: 350 أو طول 4 أمتار)"
            inputType = InputType.TYPE_CLASS_TEXT
        }

        val count = EditText(this).apply {
            hint = "العدد (مثال: 6 قطعة أو 5 كراتين)"
            inputType = InputType.TYPE_CLASS_TEXT
        }

        if (index >= 0) {
            val m = materials[index]
            type.setText(m.type)
            measure.setText(m.measure)
            count.setText(m.count)
        }

        box.addView(TextView(this).apply {
            text = "اكتب بيانات البضاعة"
            textSize = 17f
        })
        box.addView(type)
        box.addView(measure)
        box.addView(count)

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (index < 0) "إضافة صنف" else "تعديل الصنف")
            .setView(box)
            .setPositiveButton("حفظ", null)
            .setNegativeButton("إلغاء", null)

        if (index >= 0) dialog.setNeutralButton("حذف", null)

        val d = dialog.create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val product = type.text.toString().trim()
                if (product.isEmpty()) {
                    type.error = "اكتب اسم المنتج"
                    return@setOnClickListener
                }

                val item = Material(
                    product,
                    measure.text.toString().trim(),
                    count.text.toString().trim()
                )

                if (index < 0) materials.add(item)
                else materials[index] = item

                save()
                refresh()
                d.dismiss()
            }

            if (index >= 0) {
                d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    materials.removeAt(index)
                    save()
                    refresh()
                    d.dismiss()
                }
            }
        }

        d.show()
    }

    private fun featherScreen() {
        val l = base()

        l.addView(TextView(this).apply {
            text = "حساب عدد الريش"
            textSize = 26f
            gravity = Gravity.CENTER
        })

        l.addView(backButton())

        val height = EditText(this).apply {
            hint = "ارتفاع الدرابية بالسنتيمتر"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }

        l.addView(TextView(this).apply {
            text = "ارتفاع الريشة الواحدة: 10.5 سم"
            textSize = 18f
            setPadding(0, 18, 0, 18)
        })

        val result = TextView(this).apply {
            textSize = 21f
            setPadding(0, 25, 0, 25)
        }

        val calculate = btn("احسب عدد الريش")
        l.addView(height)
        l.addView(calculate)
        l.addView(result)

        calculate.setOnClickListener {
            val h = height.text.toString().replace(',', '.').toDoubleOrNull()
            if (h != null && h > 0) {
                result.text = "عدد الريش المطلوب: ${ceil(h / 10.5).toInt()} ريشة"
            } else {
                result.text = "أدخل الارتفاع بالسنتيمتر"
            }
        }

        setContentView(l)
    }

    private fun weightScreen() {
        val l = base()

        l.addView(TextView(this).apply {
            text = "حساب وزن الريش"
            textSize = 26f
            gravity = Gravity.CENTER
        })

        l.addView(backButton())

        val thickness = Spinner(this)
        val options = arrayOf(
            "4 ديسم — 4800 غ/م²",
            "4.5 ديسم — 5300 غ/م²"
        )
        thickness.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            options
        )

        val width = EditText(this).apply {
            hint = "العرض بالمتر"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }

        val height = EditText(this).apply {
            hint = "الارتفاع بالمتر"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }

        val result = TextView(this).apply {
            textSize = 21f
            setPadding(0, 25, 0, 25)
        }

        val calculate = btn("احسب الوزن")

        l.addView(thickness)
        l.addView(width)
        l.addView(height)
        l.addView(calculate)
        l.addView(result)

        calculate.setOnClickListener {
            val w = width.text.toString().replace(',', '.').toDoubleOrNull()
            val h = height.text.toString().replace(',', '.').toDoubleOrNull()

            if (w != null && h != null && w > 0 && h > 0) {
                val rate = if (thickness.selectedItemPosition == 0) 4800.0 else 5300.0
                val area = w * h
                val grams = area * rate
                val kg = grams / 1000.0

                result.text =
                    "المساحة: ${format(area)} م²\nالوزن: ${format(kg)} كغ"
            } else {
                result.text = "أدخل العرض والارتفاع"
            }
        }

        setContentView(l)
    }

    private fun format(value: Double): String =
        String.format(Locale.US, "%.3f", value)

    private fun shareOrder() {
        if (materials.isEmpty()) {
            Toast.makeText(this, "لا توجد معلومات لمشاركتها", Toast.LENGTH_SHORT).show()
            return
        }

        val text = buildString {
            append("📏 قياسات - ادارة المواد\n\n")
            materials.forEachIndexed { i, m ->
                append("${i + 1}- ${m.type} | القياس: ${m.measure.ifBlank { "—" }} | العدد: ${m.count.ifBlank { "—" }}\n")
            }
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }

        startActivity(Intent.createChooser(intent, "مشاركة الطلبية"))
    }

    private fun save() {
        prefs.edit()
            .putString(
                "data",
                materials.joinToString("\n") {
                    "${it.type.replace("|", " ")}|${it.measure.replace("|", " ")}|${it.count.replace("|", " ")}"
                }
            )
            .apply()
    }

    private fun load() {
        materials.clear()
        prefs.getString("data", "")!!
            .lines()
            .filter { it.contains("|") }
            .forEach {
                val parts = it.split("|", limit = 3)
                if (parts.size == 3) {
                    materials.add(Material(parts[0], parts[1], parts[2]))
                }
            }
    }
}
